const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

let users = {};

app.use(express.static(path.join(__dirname, 'public')));

io.on('connection', (socket) => {
    console.log('a user connected');
    
    socket.on('set username', (username) => {
        users[socket.id] = username;
        io.emit('user list', Object.values(users));
        io.emit('user connected', { username, timestamp: new Date().toLocaleTimeString() });
        console.log(users);
    });

    socket.on('chat message', (msg) => {
        io.emit('chat message', msg);
    });

    socket.on('disconnect', () => {
        console.log('user disconnected');
        const username = users[socket.id];
        delete users[socket.id];
        io.emit('user list', Object.values(users));
        io.emit('user disconnected', { username, timestamp: new Date().toLocaleTimeString() });
        console.log(users);
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
