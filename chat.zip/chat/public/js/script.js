const socket = io();
const username = localStorage.getItem('username') || 'Anonymous';

// Enviar o nome do usuário quando ele se conectar
socket.emit('set username', username);

document.querySelector('#messageInput').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        const messageText = e.target.value;
        if (messageText.trim() !== '') {
            const message = {
                timestamp: new Date().toLocaleTimeString(),
                username: username,
                text: messageText
            };
            socket.emit('chat message', message);
            e.target.value = '';
        }
    }
});

socket.on('chat message', function(msg) {
    const message = document.createElement('div');
    message.classList.add('message');
    message.innerHTML = `<span class="timestamp">${msg.timestamp}</span> <span class="username">${msg.username}</span>: ${msg.text}`;
    document.querySelector('#chatMessages').appendChild(message);
    document.querySelector('#chatMessages').scrollTop = document.querySelector('#chatMessages').scrollHeight;
});

socket.on('user list', function(users) {
    const userList = document.querySelector('#userList');
    userList.innerHTML = '';
    users.forEach(user => {
        const userItem = document.createElement('li');
        userItem.textContent = '@' + user;
        userList.appendChild(userItem);
    });
});

socket.on('user connected', function(data) {
    const notification = document.createElement('div');
    notification.classList.add('message');
    notification.innerHTML = `<span class="timestamp">${data.timestamp}</span> <span class="console">CONSOLE~#</span> O ${data.username} ACABOU DE SE CONECTAR AO CHAT`;
    document.querySelector('#chatMessages').appendChild(notification);
    document.querySelector('#chatMessages').scrollTop = document.querySelector('#chatMessages').scrollHeight;
});

socket.on('user disconnected', function(data) {
    const notification = document.createElement('div');
    notification.classList.add('message');
    notification.innerHTML = `<span class="timestamp">${data.timestamp}</span> <span class="console">CONSOLE~#</span> O ${data.username} ACABOU DE SE DESCONECTAR DO CHAT`;
    document.querySelector('#chatMessages').appendChild(notification);
    document.querySelector('#chatMessages').scrollTop = document.querySelector('#chatMessages').scrollHeight;
});
