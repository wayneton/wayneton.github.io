document.addEventListener('DOMContentLoaded', function () {
    const socket = io(); // Conecta-se ao servidor Socket.io

    const urlParams = new URLSearchParams(window.location.search);
    const username = urlParams.get('username');

    // Se não houver username, redirecionar para a página de login
    if (!username) {
        window.location.href = '/';
    }

    const messageForm = document.querySelector('.chat-input form');
    const messageInput = document.getElementById('messageInput');
    const chatMessages = document.querySelector('.chat-messages');

    messageForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const messageText = messageInput.value.trim();
        if (messageText) {
            socket.emit('chat message', { username, message: messageText }); // Envia a mensagem para o servidor
            messageInput.value = '';
        }
    });

    socket.on('chat message', function (msg) {
        const message = document.createElement('div');
        message.classList.add('message');
        message.innerHTML = `<span class="username">${msg.username}</span>: ${msg.message}`;
        chatMessages.appendChild(message);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    });
});
